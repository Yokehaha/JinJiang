<template>
  <div class="box">
    <div><img src="../assets/nba/HORNETS.jpg" alt=""></div>
    <div><img src="../assets/nba/HAWKS.jpg" alt=""></div>
  </div>
    
    
</template>

<script>
export default {
  
}
</script>