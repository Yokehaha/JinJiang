<template> 
    <el-row> 
        <el-col :span="24"> 
            <div class="footer_style">
                <pre><h2>四川大学锦江学院   地址：四川·彭山·锦江大道一号   邮编：620860   Copyright@2011-2018   四川大学锦江学院版权所有   蜀ICP备 12028597号</h2></pre>
            </div> 
        </el-col> 
    </el-row> 
</template>

<style scoped>
    .footer_style{ 
        background-color: rgb(70, 5, 100);
        color: white;
        padding-top: 10px;
        padding-bottom: 10px;
        text-align: center;
    }
</style>