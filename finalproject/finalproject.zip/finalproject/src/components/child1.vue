<template>
  <div class="box">
    <div><img src="../assets/nba/76ERS.jpg" alt=""></div>
    <div><img src="../assets/nba/BLAZERS.jpg" alt=""></div>
  </div>
    
    
</template>

<script>
export default {
  
}
</script>