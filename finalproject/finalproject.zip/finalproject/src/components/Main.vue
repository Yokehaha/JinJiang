<template>
  <div id="main">
    <v_deng></v_deng>
  </div>
</template>

<script>
import Deng from '@/components/Deng'

export default {
  name: 'mains',
  components: {
    'v_deng': Deng
  }
}
</script>

<style lang="css" scoped>
  
</style>